# A Play Framework Java Starter Application


## Uses a Bootstrap 4 template
## Content Security policy defaults have been configured
